package org.tensorflow.demo;

import android.os.Bundle;
import android.app.Activity;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class DetailActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        init();
    }

    private void init() {
        // 获取传递过来的信息。
        String infoString = getIntent().getStringExtra("cid");
        TextView subTextView = (TextView) findViewById(R.id.detail_title);
        subTextView.setText("Target==="+infoString);
        //创建数据存储源
        ArrayList<HashMap<String,Object>> list = new ArrayList<HashMap<String,Object>>();
        for(int i=1;i<=3;i++){
            //生成数据并存入list
            HashMap<String,Object> map = new HashMap<String,Object>();
            map.put("img", R.drawable.classify);
            map.put("text", "接下来是第"+(i+1)+"个");
            list.add(map);
        }
        //绑定animal_listView布局
        ListView listView = (ListView)findViewById(R.id.detail_listView);
        //创建一个SimpleAdapter适配器
        SimpleAdapter adapter = new SimpleAdapter(DetailActivity.this,
                //数据源
                list,
                //要显示内容的布局
                R.layout.imageview_detail,
                //子布局中控件id名与map中键值对应获取数据
                new String[]{"img"},
                //将获取的数据在对应子布局id上显示
                new int[]{R.id.imageViewitem});
        listView.setAdapter(adapter);
    }

}
