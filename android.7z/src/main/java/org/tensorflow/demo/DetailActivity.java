package org.tensorflow.demo;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class DetailActivity extends Activity {

    private ListView listView = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        init();
    }

    private void init() {
        // 获取传递过来的信息。
        String infoString = getIntent().getStringExtra("cid");
        TextView subTextView = (TextView) findViewById(R.id.detail_title);
        subTextView.setText("Target==="+infoString);

        //绑定animal_listView布局
        listView = (ListView)findViewById(R.id.detail_listView);
//        showImageByThead();
        initList();

    }

    private void initList(){
        BaseAdapter adapter = new BaseAdapter() {

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // TODO 自动生成的方法存根
                View layout=View.inflate(DetailActivity.this, R.layout.imageview_detail, null);
                ImageView face = (ImageView)layout.findViewById(R.id.imageViewitem);

                face.setImageResource(R.drawable.classify);

                return layout;
            }

            @Override
            public long getItemId(int position) {
                // TODO 自动生成的方法存根
                return position;
            }

            @Override
            public Object getItem(int position) {
                // TODO 自动生成的方法存根
                return position;
            }

            @Override
            public int getCount() {
                // TODO 自动生成的方法存根
                return 1;
            }
        };///new BaseAdapter()

        listView.setAdapter(adapter);
    }
    private Handler mHandler = new Handler(){
        public void handleMessage(android.os.Message msg) {
            super.handleMessage(msg);
            //创建数据存储源
            ArrayList<HashMap<String,Object>> list = new ArrayList<HashMap<String,Object>>();
            for(int i=1;i<=3;i++){
                //生成数据并存入list
                HashMap<String,Object> map = new HashMap<String,Object>();
                map.put("img", R.drawable.classify);
                list.add(map);
            }
            //创建一个SimpleAdapter适配器
            SimpleAdapter adapter = new SimpleAdapter(DetailActivity.this,
                    //数据源
                    list,
                    //要显示内容的布局
                    R.layout.imageview_detail,
                    //子布局中控件id名与map中键值对应获取数据
//                    new String[]{"img"},
//                    //将获取的数据在对应子布局id上显示
//                    new int[]{R.id.imageViewitem});
                    new String[]{},
                    //将获取的数据在对应子布局id上显示
                    new int[]{});
            listView.setAdapter(adapter);
        }
    };

    public void showImageByThead(){
        new Thread(){
            public void run() {
                Message message = Message.obtain();
                message.obj="";
                mHandler.sendMessage(message);
            };
        }.start();
    }
}
