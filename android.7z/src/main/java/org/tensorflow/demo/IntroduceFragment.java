package org.tensorflow.demo;


import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import org.tensorflow.demo.env.Logger;

public class IntroduceFragment extends Fragment {
    private static final Logger LOGGER = new Logger();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        LOGGER.i("IntroduceFragment create");
        return inflater.inflate(R.layout.fragment_law, container, false);
    }
}
