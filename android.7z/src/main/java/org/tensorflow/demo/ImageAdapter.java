package org.tensorflow.demo;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import org.tensorflow.demo.env.Logger;

public class ImageAdapter extends BaseAdapter {
    private static final Logger LOGGER = new Logger();
    private int count =0;
    private Context context=null;

    public ImageAdapter(Context context, int count){
        this.context = context;
        this.count = count;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        LOGGER.i("ImageAdapter getView",position);
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView = null;

        if (convertView == null) {
            gridView = inflater.inflate(R.layout.imageview_main, null);
            ImageView imageView = (ImageView)gridView.findViewById(R.id.imageViewitem);
            imageView.setImageResource(R.drawable.classify);
        } else {
            gridView = convertView;
        }

        return gridView;
    }

    // 要渲染的单元格数量
    @Override
    public int getCount() {
        return count;
    }

    // 在这个示例中不用，Android 要求实现此方法
    @Override
    public Object getItem(int position) {
        return null;
    }

    // 在这个示例中不用，Android 要求实现此方法
    @Override
    public long getItemId(int position) {
        return 0L;
    }

}
