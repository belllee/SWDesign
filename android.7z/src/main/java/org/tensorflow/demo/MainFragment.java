package org.tensorflow.demo;


import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import org.tensorflow.demo.env.Logger;

public class MainFragment extends Fragment {
    private static final Logger LOGGER = new Logger();
    private GridView gridview = null;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        LOGGER.i("MainFragment create");
        View view = inflater.inflate(R.layout.fragment_main, container, false);
        gridview = (GridView) view.findViewById(R.id.gridView);
        initGridView(this.getContext());
        return view;
    }

    private void initGridView(final Context context) {
        LOGGER.i("MainFragment initGridView",context);
        gridview.setAdapter(new ImageAdapter(context, 3));
        // 当用户单击时触发的事件
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View view,int position, long id) {
                LOGGER.i("MainFragment click position=",position);
                //弹出一个浮动的框进行数据显示
                Toast.makeText(context, ""+position, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(context,DetailActivity.class);
                intent.putExtra("cid",position+"");
                startActivity(intent);
            }
        });
    }
}
